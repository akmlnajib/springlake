<div class="card">
    <?php
    include "metode.php";
    ?>
</div>