<ul class="nav justify-content-center bg-success">
    <li class="nav-item">
        <a class="nav-link active" href="./?page=beranda" style="color: white;">Beranda</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./?page=hasil" style="color: white;">Hasil & Analisa</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="logout.php" style="color: white;">Keluar</a>
    </li>
</ul>